def datatrans():
    return None
#ifndef BUFFER_H
#define BUFFER_H
#include "base.h"

#define BUFFER_SIZE 128

typedef struct {
    u16 len;
    char* delimiter;
    char buffer[BUFFER_SIZE];
} RecvBuffer;
void initBuffer();
bool handleReceive(RecvBuffer* buffer,char data);
#endif
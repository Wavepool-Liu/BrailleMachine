#ifndef IOCTRL_H
#define IOCTRL_H

#define GROUP_SIZE 16
#define GROUP_COUNT 7

#include "base.h"

#include "led.h"
#include "urat.h"
u8 setIo(u8 address,u8 value);
#endif
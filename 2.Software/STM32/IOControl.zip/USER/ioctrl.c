#ifndef IOCTRL_C
#define IOCTRL_C
#include "ioctrl.h"
/*
void prepareIo() {
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;


    GPIO_TypeDef* GPIOx[]= {GPIOB,GPIOC,GPIOD,GPIOE,GPIOF,GPIOG};
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    GPIO_Init(GPIOD, &GPIO_InitStructure);
    GPIO_Init(GPIOE, &GPIO_InitStructure);
    GPIO_Init(GPIOF, &GPIO_InitStructure);
    GPIO_Init(GPIOG, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOF , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOG , ENABLE);

    for (u8 group=0; group<GROUP_SIZE; group++) {
        GPIO_TypeDef* groupName=GPIOx[group];
        for (u8 index=0; index<GROUP_SIZE; index++) {
            GPIO_ResetBits(groupName,index);
        }
    }



}

u8 setIo(u8 address,u8 value) {

    value=(value!=0);
    //0~96
    //00~15 B
    //16~31 C
    //32~47 D
    //48~63 E
    //64~71 F
    //72~95 G


    u8 group=address/GROUP_SIZE;
    u8 index=address/GROUP_SIZE;
    switch(group) {
    case 0:
        PBout(index)=value;
        break;
    case 1:
        PCout(index)=value;
        break;
    case 2:
        PDout(index)=value;
        break;
    case 3:
        PEout(index)=value;
        break;
    case 4:
        PFout(index)=value;
        break;
    case 5:
        PGout(index)=value;
        break;
    default:
        return 0xff;

    }
    return address;

}
*/
#endif
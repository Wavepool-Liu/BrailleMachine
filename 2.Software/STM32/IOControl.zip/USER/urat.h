#ifndef URAT_H
#define URAT_H
#include "stm32f10x_usart.h"
void initUrat1(uint32_t baud);
void initUrat2(uint32_t baud);
void initUrat3(uint32_t baud);
void sendUrat(USART_TypeDef *urat,const char *dat ) ;
#endif

#ifndef BUFFER_C
#define BUFFER_C
#include "buffer.h"
#include "string.h"
#include "base.h"


bool handleReceive(RecvBuffer* buffer,char data) {

    if (strchr(buffer->delimiter,data)!=NULL) {
        buffer->buffer[buffer->len]='\0';
        buffer->len=0;
        return true;
    } else {
        if (buffer->len>=sizeof(buffer->buffer)) {
            //buffer out
            buffer->len=0;
        } else {
            buffer->buffer[buffer->len++]=data;
        }
        return false;
    }
}
#endif
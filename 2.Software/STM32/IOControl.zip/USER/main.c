
#include "base.h"
#include "led.h"
#include "urat.h"
#include "misc.h"
#include "ioctrl.h"
#include <string.h>
void prepareIoA() {
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = (GPIO_Pin_All&(~ GPIO_Pin_10))&(~ GPIO_Pin_9);
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA , ENABLE);
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    for (u8 index=0; index<GROUP_SIZE; index++) {
        GPIO_ResetBits(GPIOA,index);
    }
}
int fputc(int ch)
{
	USART_SendData(USART1, (unsigned char) ch);
	while( USART_GetFlagStatus(USART1,USART_FLAG_TC)!= SET);	
	return (ch);
}
void prepareIo() {
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;


    GPIO_TypeDef* GPIOx[]= {
        GPIOB,
        GPIOC,
        GPIOD,
        GPIOE,
        GPIOF,
        GPIOG
    };


    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOD , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOF , ENABLE);
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOG , ENABLE);

    for (u8 group=0; group<6; group++) {
        GPIO_TypeDef* groupName=GPIOx[group];
        GPIO_Init(groupName, &GPIO_InitStructure);
        for (u8 index=0; index<GROUP_SIZE; index++) {
            GPIO_ResetBits(groupName,index);
        }
    }



}

u8 setIo(u8 address,u8 v) {

   u8 value=(v!=0);
    //0~96
    //00~15 B
    //16~31 C
    //32~47 D
    //48~63 E
    //64~71 F
    //72~95 G


    u8 group=address/GROUP_SIZE;
    u8 index=address%GROUP_SIZE;
    switch(group) {
    case 0:
        PBout(index)=value;
        break;
    case 1:
        PCout(index)=value;
        break;
    case 2:
        PDout(index)=value;
        break;
    case 3:
        PEout(index)=value;
        break;
    case 4:
        PFout(index)=value;
        break;
    case 5:
        PGout(index)=value;
        break;
		case 6:
				if(index==9||index==10){
					break;
				}
        PAout(index)=value;
        break;
    default:
        return 0xff;

    }
    return address;

}
void initIo() {
    for (u8 i=0; i<96; i++) {
        setIo(i,0);
    }
    PAout(15)=0;
    PAout(13)=0;
}
u8 lastCommand=0xfe;

void testTrinkleAll(){
	u8 v=0;
	while(1){
		v=!v;
		for (u8 i=0;i<=127;i++){
			setIo(i,v);
		}
		delay_ms(1000);
	}
	
}
void disableJTag() {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);
}

int main(void) {

    disableJTag();

    prepareIoA();

    prepareIo();
    initIo();


    initUrat1(9600);

    //testTrinkleAll();
    while (1) {
        delay_ms(1000);
				fputc(0xfe);
        
    }
}


void onCommand(u8 data) {

    u8 address= data&0x7f;
    u8 value=(data&0x80)!=0;

    u8 ret= setIo(address,value);
		fputc(data);
		//lastCommand=data;
    //USART_SendData(USART1,data);
	
    //delay_ms(1);
    //USART_SendData(USART1,ret);
		//delay_ms(1);
    //USART_SendData(USART1,value);
}
void USART1_IRQHandler(void) {
    if(USART_GetITStatus(USART1,USART_IT_RXNE)!=RESET) {
				USART_ClearITPendingBit(USART1,USART_IT_RXNE);
				onCommand(USART_ReceiveData(USART1));
				
    }
}






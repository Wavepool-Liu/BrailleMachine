
#ifndef USART_C
#define USART_C
#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "stm32f10x_usart.h"
#include "base.h"
//PA9 TX
//PA10 RX
void initUrat1(uint32_t baud) {
    GPIO_InitTypeDef GPIO_InitStrue;
    USART_InitTypeDef USART_InitStrue;
    NVIC_InitTypeDef NVIC_InitStrue;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);    //GPIO端口使能
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);   //串口使能

    GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;               //推挽输出
    GPIO_InitStrue.GPIO_Pin=GPIO_Pin_9;                     //PA9
    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_10MHz;             //翻转速度
    GPIO_Init(GPIOA,&GPIO_InitStrue);                       //GPIO端口初始化

    GPIO_InitStrue.GPIO_Mode=GPIO_Mode_IN_FLOATING;         //浮空输入
    GPIO_InitStrue.GPIO_Pin=GPIO_Pin_10;                    //PA10
    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_10MHz;             //翻转速度
    GPIO_Init(GPIOA,&GPIO_InitStrue);                       //GPIO端口初始化

    USART_InitStrue.USART_BaudRate = baud  ;                                     //波特率
    USART_InitStrue.USART_HardwareFlowControl=USART_HardwareFlowControl_None;      //无流控制
    USART_InitStrue.USART_Mode=USART_Mode_Tx|USART_Mode_Rx;                        //输入输出模式
    USART_InitStrue.USART_Parity=USART_Parity_No;                                  //无校验
    USART_InitStrue.USART_StopBits=USART_StopBits_1;                               //停止位
    USART_InitStrue.USART_WordLength=USART_WordLength_8b;                          //数据位
    USART_Init(USART1,&USART_InitStrue);                                           //串口参数初始化

    USART_Cmd(USART1,ENABLE);                            //使能串口1
    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);         //开启接收中断

    NVIC_InitStrue.NVIC_IRQChannel=USART1_IRQn;          //指定IRQ通道
    NVIC_InitStrue.NVIC_IRQChannelCmd=ENABLE;            //中断使能
    NVIC_InitStrue.NVIC_IRQChannelPreemptionPriority=1;  //指定优先级
    NVIC_InitStrue.NVIC_IRQChannelSubPriority=1;         //
    NVIC_Init(&NVIC_InitStrue);                          //中断初始化


}


//PA2 TX
//PA3 RX
void initUrat2(uint32_t baud) {
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2|RCC_APB2Periph_AFIO, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);


    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_InitStructure.USART_BaudRate = baud;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    USART_Cmd(USART2, ENABLE);
}



//PB10 TX
//PB11 RX
void initUrat3(uint32_t baud) {
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_InitStructure.USART_BaudRate = baud;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USART3, &USART_InitStructure);
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

    USART_Cmd(USART3, ENABLE);
}


void sendUrat(USART_TypeDef *urat,const char *dat ) {
    uint i = 0;
    uint len = strlen( dat );
    for ( i = 0; i < len; i++ ) {
        USART_SendData( urat, dat[i] );
        delay_ms( 1 );
    }
}

#endif
#include "base.h"
#include "GPIOLIKE51.h"

void delay_ms( uint16_t time_ms ) {
    uint16_t i,j;
    for( i=0; i<time_ms; i++ ) {
        for( j=0; j<10309; j++ ); //1ms
    }
}





#ifndef LED_H
#define LED_H
#include "base.h"
void initLed0(void);
void twinkleLed0(uint16_t count,uint16_t ms);

void initLed1(void);
void twinkleLed1(uint16_t count,uint16_t ms);
#endif

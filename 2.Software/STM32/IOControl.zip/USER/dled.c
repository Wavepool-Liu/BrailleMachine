#include "base.h"
//io2 sclk pe15
//io4 rclk pe13
//io6 dio pe11
u16 LED_0F[] = {
    0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x8C,0xBF,0xC6,0xA1,0x86,0xFF,0xbf
};



#define SCLK PEout(15)

#define RCLK PEout(13)

#define DIO PEout(11)

void LEDout(u8 x);
void led4show(int r,int j,int k,int l) {

    LEDout(LED_0F[l]);
    LEDout(0x01);
    RCLK = 1;
    RCLK = 0;


		delay_ms(10);
   
    LEDout(LED_0F[k]);
    LEDout(0x02);
    RCLK = 1;
    RCLK = 0;

		delay_ms(10);
    LEDout(LED_0F[j]);
    LEDout(0x04);
    RCLK = 1;
    RCLK = 0;

		delay_ms(10);
    
    LEDout(LED_0F[r]);
    LEDout(0x08);
    RCLK = 1;
    RCLK = 0;
		
}


void LEDout(u8 x) {
    u8 i;
    for(i=7; i>=0; i--) {
				DIO=x&(1<<i);
        //if (x&0x80)
				//	DIO=1;
        //else 
				//	DIO=0;
        //x<<=1;
        SCLK = 1;
        SCLK = 0;
    }
}
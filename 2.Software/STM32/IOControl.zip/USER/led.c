#ifndef LED_C
#define LED_C
#include "led.h"

//PE6
void initLed0(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}

void twinkleLed0(uint16_t count,uint16_t ms) {
    while(count-->0) {
        PEout(6)=0;
        delay_ms(ms);
        PEout(6)=1;
        delay_ms(ms);
    }
}
//PE5
void initLed1(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOE , ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}

void twinkleLed1(uint16_t count,uint16_t ms) {
    while(count-->0) {
        PEout(5)=0;
        delay_ms(ms);
        PEout(5)=1;
        delay_ms(ms);
    }
}

#endif
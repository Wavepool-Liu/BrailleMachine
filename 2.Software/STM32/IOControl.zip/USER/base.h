#ifndef BASE_H
#define BASE_H
#include "string.h"
#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "stm32f10x_usart.h"
typedef u8 bool;

typedef unsigned int uint;

#define true (1)
#define false (0)
void delay_ms( uint16_t time_ms );
//void sendUrat(USART_TypeDef *urat,const char *dat );
#endif